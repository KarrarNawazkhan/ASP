package com.example.hw15updatedpm;

public class StepEntry {
    private int id;
    private String date;
    private int stepCount;

    // Constructor
    public StepEntry(int id, String date, int stepCount) {
        this.id = id;
        this.date = date;
        this.stepCount = stepCount;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public int getStepCount() {
        return stepCount;
    }

    // Setters if needed
    // public void setId(int id) { this.id = id; }
    // public void setDate(String date) { this.date = date; }
    // public void setStepCount(int stepCount) { this.stepCount = stepCount; }
}
