package com.example.hw15updatedpm;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.widget.TextView;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor mSensor;
    private boolean isSensorPresent;
    private StepsDBHelper dbHelper;
    private BroadcastReceiver stepUpdateReceiver;
    private ListView listViewSteps;
    private StepsListAdapter adapter;
    private List<StepEntry> stepEntries;
    private TextView mStepsSinceReboot;
    private Button resetButton;
    private int initialStepCount=-1;
    private int lastStepCount=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        // Initialize components
        mStepsSinceReboot = findViewById(R.id.stepssincereboot);
        listViewSteps = findViewById(R.id.listViewSteps);
        resetButton = findViewById(R.id.resetButton);// Ensure you have a ListView with this ID in your layout
        stepEntries = new ArrayList<>();
        adapter = new StepsListAdapter(this, R.layout.list_row, stepEntries);
        listViewSteps.setAdapter(adapter);

        // Initialize sensor and database helper
        dbHelper = new StepsDBHelper(this);
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null) {
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            isSensorPresent = true;
        } else {
            isSensorPresent = false;
            mStepsSinceReboot.setText("Step Counter Sensor not available!");
        }

        // Request permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 1);
        }

        // Start the StepService
        startService(new Intent(this, StepService.class));

        // Register broadcast receiver to get updates from StepService
        stepUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                updateStepList();
            }
        };

        // Reset button setup
        resetButton.setOnClickListener(v -> {
            // Reset the steps
            dbHelper.resetSteps();
            lastStepCount = 0;
            updateStepList();
            mStepsSinceReboot.setText("Steps walked: 0");
        });


        // Update the list with existing data
        updateStepList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isSensorPresent && ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED) {
            mSensorManager.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_GAME);
        }

        // Register for broadcasts when the steps are updated
        registerReceiver(stepUpdateReceiver, new IntentFilter(StepService.ACTION_UPDATE_STEPS));
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isSensorPresent) {
            mSensorManager.unregisterListener(this);
        }
        unregisterReceiver(stepUpdateReceiver);
    }

    private void updateStepList() {
        // Fetch data from the database and update the list view
        stepEntries.clear();
        stepEntries.addAll(dbHelper.getAggregatedStepEntries());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            int totalStepsSinceReboot = (int) event.values[0];

            if (initialStepCount == -1) {
                // Initialize with the first value to avoid counting steps before the app started
                initialStepCount = totalStepsSinceReboot;
            }

            // Calculate the steps taken since the app started
            int currentSessionSteps = totalStepsSinceReboot - initialStepCount;
            mStepsSinceReboot.setText("Steps walked: " + currentSessionSteps);

            // Update only if there's an increase
            if (currentSessionSteps > lastStepCount) {
                int newSteps = currentSessionSteps - lastStepCount;
                lastStepCount = currentSessionSteps; // Update the last step count

                // Add only the new steps since the last update
                if (newSteps > 0) {
                    dbHelper.createStepsEntry(newSteps);
                    sendBroadcast(new Intent(StepService.ACTION_UPDATE_STEPS));
                }
            }
        }
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (isSensorPresent) {
                    mSensorManager.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_UI);
                }
            }
        }
    }
}
