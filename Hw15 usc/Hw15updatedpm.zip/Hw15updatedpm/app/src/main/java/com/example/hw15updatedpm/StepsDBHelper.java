package com.example.hw15updatedpm;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class StepsDBHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME = "StepsDatabase";
    private static final String TABLE_STEPS_SUMMARY = "StepsSummary";
    private static final String ID = "id";
    private static final String STEPS_COUNT = "steps_count";
    private static final String CREATION_DATE = "creation_date";

    private static final String CREATE_TABLE_STEPS_SUMMARY = "CREATE TABLE " + TABLE_STEPS_SUMMARY + "("
            + ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + CREATION_DATE + " TEXT,"
            + STEPS_COUNT + " INTEGER)";

    public StepsDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_STEPS_SUMMARY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STEPS_SUMMARY);
        onCreate(db);
    }

    public boolean createStepsEntry(int steps) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String todayDate = sdf.format(new Date());

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(STEPS_COUNT, steps);
        values.put(CREATION_DATE, todayDate);

        long result = db.insert(TABLE_STEPS_SUMMARY, null, values);
        db.close();
        return result != -1;
    }

    public int getTodayStepCount() {
        int stepCount = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String todayDate = sdf.format(new Date());

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_STEPS_SUMMARY, new String[]{"SUM(" + STEPS_COUNT + ") as total"},
                CREATION_DATE + "=?", new String[]{todayDate}, null, null, null);

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex("total");
            if (columnIndex != -1) {
                stepCount = cursor.getInt(columnIndex);
            }
        }
        cursor.close();
        db.close();
        return stepCount;
    }

    public List<StepEntry> getAggregatedStepEntries() {
        List<StepEntry> aggregatedEntries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + CREATION_DATE + ", SUM(" + STEPS_COUNT + ") as total_steps " +
                "FROM " + TABLE_STEPS_SUMMARY + " " +
                "GROUP BY " + CREATION_DATE + " " +
                "ORDER BY " + CREATION_DATE + " DESC";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int dateIndex = cursor.getColumnIndex(CREATION_DATE);
                int totalStepsIndex = cursor.getColumnIndex("total_steps");

                // Ensure that both indices are valid
                if (dateIndex != -1 && totalStepsIndex != -1) {
                    String date = cursor.getString(dateIndex);
                    int totalSteps = cursor.getInt(totalStepsIndex);
                    aggregatedEntries.add(new StepEntry(0,date, totalSteps));
                } else {
                    // Handle the case where the column indices are invalid
                    // For example, log an error or throw an exception
                }
            }
            cursor.close();;
        }
        return aggregatedEntries;
    }

    public void resetSteps() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_STEPS_SUMMARY, null, null);
        db.close();
    }
}
