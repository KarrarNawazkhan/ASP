package com.example.hw15updatedpm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class StepsDBHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "StepsDatabase";
    private static final String TABLE_STEPS_SUMMARY = "StepsSummary";
    private static final String ID = "id";
    private static final String STEPS_COUNT = "stepscount";
    private static final String CREATION_DATE = "creationdate";

    // SQL to create the table
    private static final String CREATE_TABLE_STEPS_SUMMARY = "CREATE TABLE " + TABLE_STEPS_SUMMARY + "("
            + ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + CREATION_DATE + " TEXT,"
            + STEPS_COUNT + " INTEGER)";

    public StepsDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_STEPS_SUMMARY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STEPS_SUMMARY);
        onCreate(db);
    }

    public boolean createStepsEntry(int steps) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String todayDate = sdf.format(Calendar.getInstance().getTime());

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(STEPS_COUNT, steps);
        values.put(CREATION_DATE, todayDate);

        long result = db.insert(TABLE_STEPS_SUMMARY, null, values);
        db.close();
        return result != -1;
    }

    public int getTodayStepCount() {
        int stepCount = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String todayDate = sdf.format(Calendar.getInstance().getTime());

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_STEPS_SUMMARY, new String[]{STEPS_COUNT},
                CREATION_DATE + "=?", new String[]{todayDate},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(STEPS_COUNT);
            if (columnIndex != -1) {
                stepCount = cursor.getInt(columnIndex);
            } else {
                // Log error or handle the case where the column is not found
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        return stepCount;
    }

    public List<StepEntry> getAllSteps() {
        List<StepEntry> stepEntryList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_STEPS_SUMMARY,
                new String[]{ID, CREATION_DATE, STEPS_COUNT},
                null, null, null, null, CREATION_DATE + " DESC");

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(ID);
                int dateIndex = cursor.getColumnIndex(CREATION_DATE);
                int stepsIndex = cursor.getColumnIndex(STEPS_COUNT);

                if (idIndex != -1 && dateIndex != -1 && stepsIndex != -1) {
                    int id = cursor.getInt(idIndex);
                    String date = cursor.getString(dateIndex);
                    int steps = cursor.getInt(stepsIndex);

                    StepEntry stepEntry = new StepEntry(id, date, steps);
                    stepEntryList.add(stepEntry);
                } else {
                    // Log error or handle the case where one of the columns is not found
                }
            }
            cursor.close();
        }
        return stepEntryList;
    }}

