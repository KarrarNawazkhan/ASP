package com.example.hw15updatedpm;

public class StepEntry {
    private int id;
    private String date;
    private int steps;

    public StepEntry(int id, String date, int steps) {
        this.id = id;
        this.date = date;
        this.steps = steps;
    }

    // Getter for ID
    public int getId() {
        return id;
    }

    // Getter for Date
    public String getDate() {
        return date;
    }

    // Getter for Step Count
    public int getStepCount() {
        return steps;
    }
}
