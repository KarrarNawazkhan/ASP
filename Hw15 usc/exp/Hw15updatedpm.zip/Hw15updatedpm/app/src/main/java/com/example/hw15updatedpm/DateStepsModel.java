package com.example.hw15updatedpm;

public class DateStepsModel {
    private String mDate;
    private int mStepCount;

    public DateStepsModel(String date, int stepCount) {
        this.mDate = date;
        this.mStepCount = stepCount;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        this.mDate = date;
    }

    public int getStepCount() {
        return mStepCount;
    }

    public void setStepCount(int stepCount) {
        this.mStepCount = stepCount;
    }
}
