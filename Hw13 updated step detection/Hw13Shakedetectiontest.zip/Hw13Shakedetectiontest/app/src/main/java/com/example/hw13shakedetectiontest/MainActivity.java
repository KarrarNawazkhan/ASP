package com.example.hw13shakedetectiontest;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private MediaPlayer mMediaPlayer;
    private final int[] songIds = {R.raw.baby, R.raw.lmlyd, R.raw.sorry}; // Replace with your song file names
    private float last_x = 0, last_y = 0, last_z = 0;
    private boolean isFirstValue = true;
    private int currentSongIndex = 0;
    private TextView songNameTextView; // TextView to display the song name

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        songNameTextView = findViewById(R.id.songNameTextView);
        prepareMediaPlayer(currentSongIndex);
    }

    private void prepareMediaPlayer(int songIndex) {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
        }
        mMediaPlayer = MediaPlayer.create(getApplicationContext(), songIds[songIndex]);

        // Update the TextView with the name of the current song
        String songName = getSongName(songIds[songIndex]); // Implement this method
        songNameTextView.setText("Now Playing: " + songName);

        mMediaPlayer.setOnErrorListener((mp, what, extra) -> {
            Log.e("MediaPlayer", "Error occurred: " + what + ", " + extra);
            return true;
        });
    }

    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_GAME);
    }

    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this, mAccelerometer);
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        if (!isFirstValue) {
            float deltaX = Math.abs(last_x - x);
            float deltaY = Math.abs(last_y - y);
            float deltaZ = Math.abs(last_z - z);

            float shakeThreshold = 2.5f; // Adjust this threshold based on your needs
            if (deltaX > shakeThreshold || deltaY > shakeThreshold || deltaZ > shakeThreshold) {
                if (mMediaPlayer != null) {
                    currentSongIndex = (currentSongIndex + 1) % songIds.length;
                    Log.d("MediaPlayer", "Preparing next song index: " + currentSongIndex);
                    prepareMediaPlayer(currentSongIndex);
                    mMediaPlayer.start(); // Start the playback immediately after preparing
                }
            }
        } else {
            isFirstValue = false;
        }

        last_x = x;
        last_y = y;
        last_z = z;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private String getSongName(int songId) {
        if (songId == R.raw.baby) {
            return "Baby";
        } else if (songId == R.raw.lmlyd) {
            return "LMLYD";
        } else if (songId == R.raw.sorry) {
            return "Sorry";
        } else {
            return "Unknown";
        }
    }

}

