package com.example.hw32844629;

public class BottomFragmentImpl extends BottomFragment {
}
