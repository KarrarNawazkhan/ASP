package com.example.hw16updatedsensorlisting;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Date;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private GraphView graphAccelerometer, graphGyroscope, graphLight;
    private LineGraphSeries<DataPoint> seriesAccelerometer, seriesGyroscope, seriesLight;
    private long lastUpdate = System.currentTimeMillis();
    private static final long UPDATE_INTERVAL = 30000; // Update every 30 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeGraphViews();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        registerSensorListeners();
    }

    private void initializeGraphViews() {
        graphAccelerometer = findViewById(R.id.graph_accelerometer);
        graphGyroscope = findViewById(R.id.graph_gyroscope);
        graphLight = findViewById(R.id.graph_light);

        seriesAccelerometer = new LineGraphSeries<>();
        seriesGyroscope = new LineGraphSeries<>();
        seriesLight = new LineGraphSeries<>();

        setupGraph(graphAccelerometer, seriesAccelerometer, "Accelerometer");
        setupGraph(graphGyroscope, seriesGyroscope, "Gyroscope");
        setupGraph(graphLight, seriesLight, "Light Sensor");
    }

    private void registerSensorListeners() {
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        Sensor lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void setupGraph(GraphView graph, LineGraphSeries<DataPoint> series, String title) {
        graph.addSeries(series);
        graph.setTitle(title);

        // Configure date label formatter
        graph.getGridLabelRenderer().setLabelFormatter(new DateAsXAxisLabelFormatter(this));
        graph.getGridLabelRenderer().setNumHorizontalLabels(3); // to avoid clutter

        // Set manual x bounds to show the last 30 seconds
        long currentTime = new Date().getTime();
        graph.getViewport().setMinX(currentTime - 30 * 1000);
        graph.getViewport().setMaxX(currentTime);
        graph.getViewport().setXAxisBoundsManual(true);

        // Enable scaling and scrolling
        graph.getViewport().setScalable(true);
        graph.getViewport().setScalableY(true);
        graph.getViewport().setScrollable(true);
        graph.getViewport().setScrollableY(true);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        long currentTime = System.currentTimeMillis();
        if ((currentTime - lastUpdate) >= UPDATE_INTERVAL) {
            lastUpdate = currentTime;
            DataPoint dataPoint = new DataPoint(new Date(), event.values[0]);

            switch (event.sensor.getType()) {
                case Sensor.TYPE_ACCELEROMETER:
                    seriesAccelerometer.appendData(dataPoint, true, 40);
                    break;
                case Sensor.TYPE_GYROSCOPE:
                    seriesGyroscope.appendData(dataPoint, true, 40);
                    break;
                case Sensor.TYPE_LIGHT:
                    seriesLight.appendData(dataPoint, true, 40);
                    break;
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Implement if needed
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerSensorListeners();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
}
